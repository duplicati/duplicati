using System;
using System.Collections.Generic;
using System.Text;

namespace Affirma.ThreeSharp.Model
{
    /// <summary>
    /// The response to a DistributionGet operation
    /// </summary>
    public class DistributionGetResponse : AWS100Response
    {
    }
}
