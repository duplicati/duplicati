using System;
using System.Collections.Generic;
using System.Text;

namespace Affirma.ThreeSharp.Model
{
    /// <summary>
    /// The response to a DistributionDelete operation
    /// </summary>
    public class DistributionDeleteResponse : AWS100Response
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public DistributionDeleteResponse()
        {
        }
    }
}
