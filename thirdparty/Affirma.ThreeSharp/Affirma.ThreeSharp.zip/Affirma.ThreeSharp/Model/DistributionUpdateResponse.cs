using System;
using System.Collections.Generic;
using System.Text;

namespace Affirma.ThreeSharp.Model
{
    /// <summary>
    /// The response object for a DistributionUpdate operation
    /// </summary>
    public class DistributionUpdateResponse : AWS100Response
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public DistributionUpdateResponse()
        {
        }
    }
}
