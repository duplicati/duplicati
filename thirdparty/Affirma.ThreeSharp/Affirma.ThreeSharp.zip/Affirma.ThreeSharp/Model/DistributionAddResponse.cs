using System;
using System.Collections.Generic;
using System.Text;

namespace Affirma.ThreeSharp.Model
{
    /// <summary>
    /// The response to a DistributionAdd operation
    /// </summary>
    public class DistributionAddResponse : AWS100Response
    {
    }
}
