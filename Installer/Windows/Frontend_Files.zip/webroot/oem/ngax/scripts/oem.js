/* Placeholder for OEM branding */
