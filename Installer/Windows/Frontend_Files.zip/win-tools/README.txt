﻿This folder contains some utility tools for Windows, bundled with Duplicati.

The file gpg.exe is actually "gpg2.exe" from the package "gpg4win-2.3.3".
The renaming is done to make it easier to call "gpg" from Duplicati.